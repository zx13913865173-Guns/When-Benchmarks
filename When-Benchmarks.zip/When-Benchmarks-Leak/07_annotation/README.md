# 07 — 专家标注与裁定（Expert Annotation）

对应论文 **§2.5**。由 **4 位专家**（跨文化艺术分析经验 ≥5 年）对 140 张图给出
风格标签，作为 ground truth；随后计算评分者一致性（Fleiss κ）并裁定分歧。

## 1. 标注流程

1. 每位专家获得随机匿名 ID（E1–E4），只看到**图像 ID 与图像本身**，不含生成元数据。
2. 每张图标注其包含的**风格集合**（多标签），并可给出主/次风格判断。
3. 4 份标签汇总到 `annotation_template.csv`。
4. 一致性用 **Fleiss κ** 度量；论文报告 **κ = 0.81**（几乎完全一致）。
5. 分歧通过裁定规则（多数投票 + 专家复议）解决，产出 `ground_truth.csv`。

## 2. 文件

| 文件 | 内容 |
|---|---|
| `annotation_template.csv` | 140 行标注模板，含 image_id、category 与 4 位专家的标签列 |
| `fleiss_kappa.py` | 计算 Fleiss κ 与每图一致性 |
| `adjudicate_labels.py` | 由专家标签裁定出 `ground_truth.csv`（多标签真值） |

## 3. 标注模板字段

| 字段 | 含义 |
|---|---|
| `image_id` | 与基准清单一致 |
| `category` | 图像类别（便于分层核对） |
| `expert_1` … `expert_4` | 各专家给出的风格集合，分号分隔；无法判断填 `none` |

## 4. 运行

```bash
python fleiss_kappa.py --annotations annotation_template.csv --out ../outputs/fleiss_kappa.csv
python adjudicate_labels.py --annotations annotation_template.csv --out ground_truth.csv
```

## 5. 伦理

- 同意书 + 匿名 ID；标注文件只含图像 ID 与风格标签。
- 数据加密存储；无个人可识别信息。
- 标注为自愿参与；无补偿。
