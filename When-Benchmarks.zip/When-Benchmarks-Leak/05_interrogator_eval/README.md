# 05 — CLIP Interrogator 评估与指标（Evaluation & Metrics）

对应论文 **§2.4、§2.7 与 §3.4–3.7**。对 140 张基准图运行 CLIP Interrogator，
把生成的 prompt 映射为风格标签，再与专家 ground truth 比对，产出
recall / precision / F1 / coverage 及 dominant–secondary 指标。

## 1. 工具配置（论文 §2.4）

| 项目 | 取值 |
|---|---|
| CLIP Interrogator | **v0.6.0** |
| CLIP 骨干 | `ViT-L-14/openai` |
| 模式 | **classic** |
| BLIP 分支 | `blip-image-captioning-base` |

> 双路径架构：BLIP 生成内容描述，CLIP 对风格描述子做图文相似度打分。
> CLIP 分支的预训练语料为 WIT 400M（不公开），这是所有代理指标的认知上限。

## 2. 指标定义（论文 §2.7）

- **多标签**：每张图的预测与真值均为风格集合，按多标签逻辑计算（Zhang & Zhou, 2014）。
- **recall / precision / F1**：标准多标签定义。
- **coverage**：真值风格被预测覆盖的比例。
- **dominant / secondary recall**：**仅在 60 张非对称图上**定义。
- **等权图的 position-1 / position-2 recall**：单独报告，**不与 dominant/secondary 混算**。

## 3. 关键结果（供核对）

| 指标 | 数值 |
|---|---|
| 非对称图 dominant recall (n=60) | **0.76** |
| 非对称图 secondary recall (n=60) | **0.22** |
| dominant − secondary 差 | **0.54** |
| 等权图 position-1 / position-2 recall | 0.72 / 0.40 |
| 0.7:0.3 条件 dominant / secondary | 0.83 / 0.19 |
| 0.3:0.7 条件 dominant / secondary | 0.69 / 0.25 |
| 颜色主导 / 纹理主导 recall | 0.76 / 0.62 |

## 4. 消融（L0–L4，论文 §2.7、§3.6）

| 层级 | 含义 | recall |
|---|---|---|
| L0 | 混合图完整流程 | 0.53 |
| L1 | 纯风格图 | 0.87 |
| L2 | 去掉 BLIP，仅 CLIP 文本编码器匹配 | 0.30 |
| L3 | 2×2 区域重询问 | 0.69 |
| L4 | 高斯噪声基线 | 0.03 |
| oracle | 理论上界（recall ≡ 1.0） | 1.00 |

## 5. 区域重询问（论文 §3.6）

低重叠子集上，区域重询问（2×2 网格）相对全局：

| 指标 | 全局 → 区域 | 变化 |
|---|---|---|
| secondary recall | 0.28 → 0.49 | **+0.21** |
| coverage | 0.61 → 0.78 | +0.17 |
| F1 | 0.42 → 0.61 | +0.19 |
| precision | 0.85 → 0.80 | −0.05 |

假阳性（全部 120 混合图）：全局 17/120 = 14.2%，区域 23/120 = 19.2%。

> 该提升为**探索性**，且与融合对**部分混淆**，非无混淆因果效应（论文 §3.6、§4.2）。

## 6. 文件

- `run_interrogator.py`：对 140 图运行 CLIP Interrogator，输出 prompt。
- `match_labels.py`：prompt → 风格标签的词表匹配。
- `regional_reinterrogation.py`：2×2 区域重询问。
- `metrics.py`：多标签指标与 dominant/secondary 指标。
- `README.md`：本文件。

## 7. 运行

```bash
python run_interrogator.py --benchmark ../outputs/benchmark_140 \
    --out ../outputs/interrogator_prompts.csv
python match_labels.py --prompts ../outputs/interrogator_prompts.csv \
    --out ../outputs/pred_labels.csv
python regional_reinterrogation.py --benchmark ../outputs/benchmark_140 \
    --out ../outputs/prompts_regional.csv
python metrics.py --pred ../outputs/pred_labels.csv \
    --meta ../03_benchmark/benchmark_metadata.csv \
    --truth ../07_annotation/ground_truth.csv \
    --out ../outputs/metrics.csv
```
