# 01 — LoRA 训练（Style LoRA Training）

对应论文 **§2.2 LoRA training on 375 images**。为 5 个风格各训练一个 LoRA adapter，
共 5 个 `.safetensors` 文件，作为后续混合图像生成的风格载体。

## 1. 五个风格

| 风格 | 文化来源 | 视觉特征类型 | 在 2×2 分类中的位置 |
|---|---|---|---|
| `ink_wash`（中国水墨） | 东亚 | 纹理主导（texture-dominant） | 东亚 × 纹理 |
| `ukiyo_e`（日本浮世绘） | 东亚 | 颜色主导（color-dominant） | 东亚 × 颜色 |
| `cyberpunk`（赛博朋克） | 西方 | 颜色主导 | 西方 × 颜色 |
| `baroque`（巴洛克） | 西方 | 纹理主导 | 西方 × 纹理 |
| `minimalist`（极简） | 无文化归属（prompt-conditioned） | — | 仅用于泛化对 |

> `minimalist` 不参与文化来源对比，只出现在泛化对（ink+minimalist、ukiyo-e+minimalist）中。

## 2. 训练集

- 规模：**375 张 = 75 张 / 风格**。
- 来源：WikiArt、The Met Open Access、Rijksmuseum，仅取 public-domain / CC0。
- 组织结构（kohya 约定）：

```
data/train/
├── ink_wash/     # 75 images + 同名 .txt 描述文件
├── ukiyo_e/
├── cyberpunk/
├── baroque/
└── minimalist/
```

## 3. 训练超参数（与论文一致）

| 参数 | 取值 |
|---|---|
| 基座 | SDXL Base 1.0 |
| network_dim (rank) | 32 |
| network_alpha | 1.0 |
| max_train_steps | 3000 |
| learning_rate | 1e-4 |
| train_batch_size | 2 |
| optimizer | AdamW |
| 分辨率 | 1024 |

## 4. 文件

- `configs/<style>.toml`：5 个风格的训练配置，参数完全一致，仅数据目录 / 输出名不同。
- `train_all.sh`：顺序训练 5 个风格。
- `prepare_dataset.md`：训练图来源、清洗与描述文件生成说明。

## 5. 运行

```bash
cd 01_lora_training
bash train_all.sh
```

产物写入 `../outputs/lora/<style>/`，文件名形如 `ink_wash_sdxl.safetensors`。
