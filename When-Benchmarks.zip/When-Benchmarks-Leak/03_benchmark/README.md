# 03 — 140 图基准与元数据（Benchmark & Metadata）

对应论文 **§2.3 与 Table 1**。本模块把生成阶段的产物整理为统一的
**140 行基准清单**，作为标注、审计与评估的公共输入。

## 1. 基准组成（Table 1）

| 类别 | 组成 | N |
|---|---|---|
| 非对称主对混合 | 4 pairs × 2 ratios × 5 reps | 40 |
| 非对称泛化对混合 | 2 pairs × 2 ratios × 5 reps | 20 |
| 等权主对混合 | 4 pairs × 2 blocks × 5 reps | 40 |
| 等权泛化对混合 | 2 pairs × 2 blocks × 5 reps | 20 |
| 纯风格对照 | 5 styles × 4 images | 20 |
| **合计** | | **140** |

## 2. 元数据字段

`benchmark_metadata.csv` 每行一张图，字段如下：

| 字段 | 含义 |
|---|---|
| `image_id` | 图像唯一标识（= 文件名去扩展名） |
| `category` | `asymmetric_primary` / `asymmetric_generalization` / `equal_weight_primary` / `equal_weight_generalization` / `pure_style_control` |
| `pair` | 融合对 id（纯风格对照为空） |
| `style_a` / `style_b` | 两个组成风格 |
| `weight_a` / `weight_b` | 权重比 |
| `block` | 等权条件下的生成块（0/1），非等权为 0 |
| `rep` | 条件内的重复序号 0–4 |
| `seed` | 实际随机种子 |
| `dominant_style` | **仅非对称图**填充；等权与纯风格图留空 |
| `secondary_style` | **仅非对称图**填充 |
| `file_name` | 图像文件名 |

> 关键约束：`dominant_style` / `secondary_style` **只对 60 张非对称图**有意义；
> 等权图按构造不能指定 dominant/secondary，必须留空（论文 §2.7 明确规定）。

## 3. 文件

- `build_benchmark_metadata.py`：由 `../02_hybrid_generation/fusion_config.json`
  与 `seeds.json` 生成完整 140 行清单。
- `benchmark_metadata.csv`：生成的清单。

## 4. 运行

```bash
python build_benchmark_metadata.py \
    --config ../02_hybrid_generation/fusion_config.json \
    --seeds ../02_hybrid_generation/seeds.json \
    --out benchmark_metadata.csv
```

## 5. 与图像文件的对应

清单中的 `file_name` 与 `02_hybrid_generation` 实际生成的 PNG 文件名一致，
因此可直接用清单驱动后续标注与评估脚本。
