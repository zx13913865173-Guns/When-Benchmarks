# 04 — 代理重叠风险审计（Proxy Overlap-Risk Audit）

对应论文 **§2.6 与 §3.1**。这是全文方法学核心：对 **375 张 LoRA 训练图**做
两阶段审计，度量其与代理语料 `LAION-2B-en` 的重叠风险。

> 为何审计训练图而非生成图：**生成图像不可能出现在任何预训练语料中**，
> 对生成图做重叠审计在构造上无意义（论文 §2.6 明确指出）。

## 1. 两阶段流程

| 阶段 | 方法 | 判定 |
|---|---|---|
| **Stage 1** | perceptual hash (pHash) 候选筛选 + SimHash 式分桶 | 海明距离 ≤ 10 记为候选 |
| **Stage 2** | CLIP 嵌入余弦相似度验证 | ≥0.95 high-similarity；0.90–<0.95 borderline；<0.90 clean |

## 2. 结果口径（论文 §3.1）

| 指标 | 数值 |
|---|---|
| pHash 候选数 | 63 / 375 = **16.8%** |
| high-similarity | 32 / 375 = **8.5%** |
| borderline | 13 / 375 = **3.5%** |
| 保守口径（high + borderline） | 45 / 375 = **12.0%** |
| 生成图与 LAION 重叠 | 0 / 140（验证生成图非重叠来源） |

样式级保守比例：ink wash 23/75 (30.7%)、Baroque 11/75 (14.7%)、
cyberpunk 7/75 (9.3%)、ukiyo-e 3/75 (4.0%)、minimalist 1/75 (1.3%)。

## 3. 对级比例与分层

**样式比例**：`ratio_style = (high + borderline) / 75`

**对级比例**（两风格均值）：

$$
\text{ratio\_pair} = \frac{\text{ratio\_style\_A} + \text{ratio\_style\_B}}{2}
$$

论文的对级比例：ink+Baroque 22.7%、ink+cyberpunk 20.0%、ink+minimalist 16.0%、
cyberpunk+Baroque 12.0%、ukiyo-e+Baroque 9.3%、ukiyo-e+minimalist 2.7%。
**无一对超过 30%**，故 120 张混合图按对级比例分为三个三分位（每层 40 张）：

- **高**：ink+Baroque、ink+cyberpunk
- **中**：ink+minimalist、cyberpunk+Baroque
- **低**：ukiyo-e+Baroque、ukiyo-e+minimalist

> 三分位是**相对**划分，"最高"指"本样本内最高"，非绝对意义上的严重重叠。

## 4. 文件

- `audit_config.py`：全部阈值与配对常量。
- `stage1_phash_screen.py`：pHash + 分桶候选筛选。
- `stage2_clip_verify.py`：CLIP 嵌入验证与 high/borderline/clean 分类。
- `pair_overlap_ratio.py`：样式级 / 对级比例与三分位分层。
- `README.md`：本文件。

## 5. 运行

```bash
# 1) 构建 LAION-2B-en 的 pHash 桶索引（一次性，离线）
python stage1_phash_screen.py build-index \
    --laion_index ../data/laion2b_en_phash.jsonl \
    --index_out ../data/laion2b_en_buckets.pkl

# 2) 对 375 张训练图做候选筛选
python stage1_phash_screen.py screen \
    --train_dir ../data/train \
    --index ../data/laion2b_en_buckets.pkl \
    --out ../outputs/stage1_candidates.csv

# 3) CLIP 嵌入验证
python stage2_clip_verify.py \
    --candidates ../outputs/stage1_candidates.csv \
    --train_dir ../data/train \
    --out ../outputs/stage2_verified.csv

# 4) 样式级 / 对级比例与三分位
python pair_overlap_ratio.py \
    --verified ../outputs/stage2_verified.csv \
    --out ../outputs/pair_overlap_ratios.csv
```

## 6. 复现边界（务必阅读）

- 代理语料 `LAION-2B-en` **不是** CLIP 的真实预训练数据；重叠比例是**下界指标**，
  不等于预训练归属。
- CLIP 默认骨干为 OpenAI ViT-L-14，其语料 `WIT 400M` 不公开、不可审计
  （论文 §1.2、§4.3）。
- 审计只使用单一海明阈值与单一 CLIP 阈值，**未做阈值扫描**（论文 §4.3）。
