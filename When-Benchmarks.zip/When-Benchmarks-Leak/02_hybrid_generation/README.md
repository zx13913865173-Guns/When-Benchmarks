# 02 — 混合图像生成（Hybrid Image Generation）

对应论文 **§2.3 Hybrid image generation**。用训练好的 5 个风格 LoRA，
在 SDXL Base 1.0 上做加权融合，生成 140 张图的基准。

## 1. 六个融合对

| 类型 | 融合对 | 说明 |
|---|---|---|
| 主对（跨 2×2 分类） | `ink_cyber`（ink_wash + cyberpunk） | 东亚×纹理 + 西方×颜色 |
| 主对 | `ukiyo_baroque`（ukiyo_e + baroque） | 东亚×颜色 + 西方×纹理 |
| 主对 | `cyber_baroque`（cyberpunk + baroque） | 纯西方对 |
| 主对 | `ink_baroque`（ink_wash + baroque） | 东亚×纹理 + 西方×纹理 |
| 泛化对 | `ink_minimal`（ink_wash + minimalist） | 含 prompt-conditioned 风格 |
| 泛化对 | `ukiyo_minimal`（ukiyo_e + minimalist） | 含 prompt-conditioned 风格 |

## 2. 权重比与重复

- 权重比：`0.3:0.7`、`0.5:0.5`、`0.7:0.3`；其中 `0.5:0.5` **重复两次**（两个 block）。
- 每个条件重复 5 次，使用基础种子派生的独立种子 `42, 43, 44, 45, 46`，
  使同条件内的 5 次为独立生成而非同一输出。
- 纯风格对照（`1.0:0.0` 与 `0.0:1.0`）单独生成。

## 3. 组成（= 论文 Table 1）

| 类别 | 组成 | N |
|---|---|---|
| 非对称主对混合 | 4 pairs × 2 ratios × 5 reps | 40 |
| 非对称泛化对混合 | 2 pairs × 2 ratios × 5 reps | 20 |
| 等权主对混合 | 4 pairs × 2 blocks × 5 reps | 40 |
| 等权泛化对混合 | 2 pairs × 2 blocks × 5 reps | 20 |
| 纯风格对照 | 5 styles × 4 images | 20 |
| **合计** | | **140** |

> 120 张混合图中，**60 张非对称**（0.3:0.7 与 0.7:0.3 各 30）、**60 张等权**
> （两个 block 各 30）。dominant/secondary 指标**仅对 60 张非对称图**定义。

## 4. 生成设置

| 参数 | 取值 |
|---|---|
| CFG scale | 7.5 |
| Inference steps | 30 |
| Sampler | DPM++ 2M Karras |
| Resolution | 1024 × 1024 |

## 5. 文件

- `fusion_config.json`：融合对、权重比、重复次数的声明式配置。
- `seeds.json`：基础种子与 block 种子偏移。
- `generate_hybrids.py`：生成脚本（diffusers 多 LoRA 加权加载）。

## 6. 运行

```bash
python generate_hybrids.py \
    --lora_dir ../outputs/lora \
    --out_dir ../outputs/benchmark_140 \
    --meta ../outputs/generation_metadata.csv
```

产物：140 张 PNG + `generation_metadata.csv`（每行一张图的生成元数据）。
